@echo off
title 4 YJET POS - Firewall
echo Adding a Private-network firewall rule for TCP port 3000...
netsh advfirewall firewall add rule name="4 YJET POS 3000" dir=in action=allow protocol=TCP localport=3000 profile=private
echo.
echo Done. If Windows asks for administrator permission, choose Yes.
pause
