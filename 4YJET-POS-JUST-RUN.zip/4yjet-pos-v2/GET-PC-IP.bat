@echo off
title 4 YJET - PC IP
echo Your network information:
echo.
ipconfig
echo.
echo Look for "IPv4 Address" under the Wi-Fi/Ethernet adapter.
echo Example: 192.168.1.50
pause
