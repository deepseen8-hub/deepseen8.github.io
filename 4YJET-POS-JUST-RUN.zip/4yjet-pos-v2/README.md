# 4 YJET POS v2

A local-network restaurant POS with two main interfaces: waiter and main/admin receiver.

## Architecture
Phone/tablet -> Wi-Fi -> Node.js server on main PC -> Socket.IO -> main/admin terminals.

SQLite is used for the local database. The server owns financial timestamps and authorization.

## Included
- Secure password hashing (bcrypt)
- JWT authentication
- Roles: admin, admin_waiter, waiter, cashier
- Gzimi and Osman initial accounts
- Waiter order entry
- Real-time new-order notification
- Main receiver pending-order queue
- Accept/reject/cancel/complete
- Order editing with audit log
- Daily dashboard and waiter totals
- Searchable order history
- Browser-print receipt/check
- Restaurant settings
- Menu management
- Waiter management
- Tables
- Audit log
- Server-side role checks
- Basic waiter call + acknowledgement API
- Payment-recording API
- Designed for future kitchen/bar printers and ESC/POS

## Initial credentials
Gzimi: gzimi / gzimi1234
Osman: osman / osaman1234

Change these immediately for real use.

## Run on the main PC
Install Node.js LTS, then in this folder:

npm install
npm start

Open http://localhost:3000 on the PC.

For phones on the same Wi-Fi, find the PC IPv4 with Windows `ipconfig`, for example 192.168.1.50, then open:

http://192.168.1.50:3000

If Windows Firewall blocks it, allow Node.js on the Private network.

## Printing
The current PRINT CHECK uses the browser print dialog, which works with a printer installed on Windows. Exact automatic thermal printing depends on the printer model and driver. For direct ESC/POS printing, the next implementation should add a small local print agent or a compatible printer API; do not guess the printer protocol until the exact model is known.

## Production notes
Set JWT_SECRET as an environment variable. Do not expose the server directly to the public internet without HTTPS, stronger session controls, backups, and a proper deployment/security review.
