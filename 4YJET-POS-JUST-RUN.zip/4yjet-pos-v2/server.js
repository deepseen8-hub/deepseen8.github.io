const express=require("express");
const http=require("http");
const {Server}=require("socket.io");
const Database=require("better-sqlite3");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const path=require("path");
const crypto=require("crypto");

const app=express(), server=http.createServer(app), io=new Server(server);
const db=new Database("4yjet-pos.db");
const SECRET=process.env.JWT_SECRET||"CHANGE_ME_4YJET_SECRET";
const TZ="Europe/Pristina";
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,role TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings(
 id INTEGER PRIMARY KEY CHECK(id=1),restaurant_name TEXT,city TEXT,region TEXT,country TEXT,
 address TEXT,phone TEXT,currency TEXT,tax_rate REAL,logo TEXT
);
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT NOT NULL,price REAL NOT NULL,
 active INTEGER NOT NULL DEFAULT 1,description TEXT
);
CREATE TABLE IF NOT EXISTS restaurant_tables(
 id INTEGER PRIMARY KEY AUTOINCREMENT,table_number TEXT UNIQUE NOT NULL,active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,device_id TEXT,table_number TEXT NOT NULL,waiter_id INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',subtotal REAL NOT NULL,tax REAL NOT NULL,total REAL NOT NULL,
 created_at TEXT NOT NULL,accepted_at TEXT,accepted_by INTEGER,cancelled_at TEXT,cancelled_by INTEGER,
 cancellation_reason TEXT,notes TEXT
);
CREATE TABLE IF NOT EXISTS order_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,product_id INTEGER NOT NULL,
 product_name TEXT NOT NULL,quantity INTEGER NOT NULL,unit_price REAL NOT NULL,total REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log(
 id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,action TEXT NOT NULL,order_id INTEGER,
 old_data TEXT,new_data TEXT,reason TEXT,timestamp TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS calls(
 id INTEGER PRIMARY KEY AUTOINCREMENT,caller_id INTEGER,waiter_id INTEGER,message TEXT,
 created_at TEXT NOT NULL,acknowledged_at TEXT
);
CREATE TABLE IF NOT EXISTS payments(
 id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,amount REAL NOT NULL,
 method TEXT NOT NULL,recorded_by INTEGER,created_at TEXT NOT NULL
);
`);

const now=()=>new Date().toISOString();
const localDate=()=>new Intl.DateTimeFormat("en-CA",{timeZone:TZ,year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date());
const audit=(user,action,order,oldData,newData,reason)=>db.prepare(
"INSERT INTO audit_log(user_id,action,order_id,old_data,new_data,reason,timestamp) VALUES(?,?,?,?,?,?,?)"
).run(user?.id||null,action,order||null,oldData?JSON.stringify(oldData):null,newData?JSON.stringify(newData):null,reason||null,now());

if(!db.prepare("SELECT 1 FROM settings WHERE id=1").get())
 db.prepare("INSERT INTO settings VALUES(1,'4 YJET','Gjakovë','Kosovë','Kosovo','','','€',0,'')").run();

if(db.prepare("SELECT COUNT(*) c FROM users").get().c===0){
 const add=(name,u,p,r)=>db.prepare("INSERT INTO users(name,username,password_hash,role,created_at) VALUES(?,?,?,?,?)")
 .run(name,u,bcrypt.hashSync(p,12),r,now());
 add("Gzimi","gzimi","gzimi1234","admin");
 add("Osman","osman","osaman1234","admin_waiter");
}
if(db.prepare("SELECT COUNT(*) c FROM products").get().c===0){
 const add=db.prepare("INSERT INTO products(name,category,price,description) VALUES(?,?,?,?)");
 [
  ["Burger","Burgers",8,""],["Cheeseburger","Burgers",9,""],["Fries","Food",3,""],
  ["Pizza Margherita","Pizza",7,""],["Coca Cola","Drinks",2,""],["Water","Drinks",1,""]
 ].forEach(x=>add.run(...x));
}
if(db.prepare("SELECT COUNT(*) c FROM restaurant_tables").get().c===0){
 const add=db.prepare("INSERT INTO restaurant_tables(table_number) VALUES(?)");
 for(let i=1;i<=20;i++) add.run(String(i));
}

function auth(req,res,next){
 try{
  const t=(req.headers.authorization||"").replace("Bearer ","");
  req.user=jwt.verify(t,SECRET); next();
 }catch(e){res.status(401).json({error:"Not authenticated"});}
}
const isAdmin=u=>["admin","admin_waiter","cashier"].includes(u.role);
const canOrder=u=>["waiter","admin_waiter"].includes(u.role);
function requireAdmin(req,res,next){if(!isAdmin(req.user))return res.status(403).json({error:"Admin permission required"});next();}

app.post("/api/login",(req,res)=>{
 const {username,password}=req.body||{},u=db.prepare("SELECT * FROM users WHERE username=? AND active=1").get(username);
 if(!u||!bcrypt.compareSync(password||"",u.password_hash))return res.status(401).json({error:"Wrong username or password"});
 const token=jwt.sign({id:u.id,name:u.name,username:u.username,role:u.role},SECRET,{expiresIn:"12h"});
 res.json({token,user:{id:u.id,name:u.name,username:u.username,role:u.role}});
});
app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.get("/api/settings",auth,(req,res)=>res.json(db.prepare("SELECT * FROM settings WHERE id=1").get()));
app.put("/api/settings",auth,requireAdmin,(req,res)=>{
 const s=req.body;
 db.prepare(`UPDATE settings SET restaurant_name=?,city=?,region=?,country=?,address=?,phone=?,currency=?,tax_rate=?,logo=? WHERE id=1`)
 .run(s.restaurant_name||"",s.city||"",s.region||"",s.country||"",s.address||"",s.phone||"",s.currency||"€",Number(s.tax_rate)||0,s.logo||"");
 audit(req.user,"Updated restaurant settings");res.json({ok:true});
});

app.get("/api/menu",auth,(req,res)=>res.json(db.prepare("SELECT * FROM products WHERE active=1 ORDER BY category,name").all()));
app.post("/api/menu",auth,requireAdmin,(req,res)=>{
 const {name,category,price,description=""}=req.body;
 const r=db.prepare("INSERT INTO products(name,category,price,description) VALUES(?,?,?,?)").run(name,category,Number(price),description);
 res.json(db.prepare("SELECT * FROM products WHERE id=?").get(r.lastInsertRowid));
});
app.patch("/api/menu/:id",auth,requireAdmin,(req,res)=>{
 const p=req.body;db.prepare("UPDATE products SET name=?,category=?,price=?,description=?,active=? WHERE id=?")
 .run(p.name,p.category,Number(p.price),p.description||"",p.active?1:0,req.params.id);res.json({ok:true});
});

app.get("/api/tables",auth,(req,res)=>res.json(db.prepare("SELECT * FROM restaurant_tables WHERE active=1 ORDER BY CAST(table_number AS INTEGER),table_number").all()));
app.post("/api/tables",auth,requireAdmin,(req,res)=>{db.prepare("INSERT INTO restaurant_tables(table_number) VALUES(?)").run(String(req.body.table_number));res.json({ok:true})});

function fullOrder(id){
 const o=db.prepare(`SELECT o.*,u.name waiter,a.name accepted_name,c.name cancelled_name
 FROM orders o LEFT JOIN users u ON u.id=o.waiter_id LEFT JOIN users a ON a.id=o.accepted_by
 LEFT JOIN users c ON c.id=o.cancelled_by WHERE o.id=?`).get(id);
 if(!o)return null;
 o.items=db.prepare("SELECT * FROM order_items WHERE order_id=?").all(id); return o;
}
app.post("/api/orders",auth,(req,res)=>{
 if(!canOrder(req.user))return res.status(403).json({error:"You cannot create orders"});
 const {table_number,items,notes="",device_id=""}=req.body;
 if(!table_number||!Array.isArray(items)||!items.length)return res.status(400).json({error:"Table and items required"});
 const get=db.prepare("SELECT * FROM products WHERE id=? AND active=1");
 let subtotal=0, normalized=[];
 for(const x of items){
  const p=get.get(Number(x.product_id)),q=Number(x.quantity);
  if(!p||!Number.isInteger(q)||q<1)return res.status(400).json({error:"Invalid product or quantity"});
  const total=p.price*q;subtotal+=total;normalized.push({p,q,total});
 }
 const taxRate=Number(db.prepare("SELECT tax_rate FROM settings WHERE id=1").get().tax_rate||0);
 const tax=Math.round(subtotal*taxRate)/100,total=subtotal+tax;
 const tx=db.transaction(()=>{
  const r=db.prepare(`INSERT INTO orders(device_id,table_number,waiter_id,status,subtotal,tax,total,created_at,notes)
   VALUES(?,?,?,?,?,?,?,?,?)`).run(device_id||crypto.randomUUID(),String(table_number),req.user.id,"pending",subtotal,tax,total,now(),notes);
  const add=db.prepare("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price,total) VALUES(?,?,?,?,?,?)");
  normalized.forEach(x=>add.run(r.lastInsertRowid,x.p.id,x.p.name,x.q,x.p.price,x.total));
  return r.lastInsertRowid;
 });
 const id=tx(),o=fullOrder(id);audit(req.user,"Created order",id,null,o);
 io.emit("new-order",o);res.status(201).json(o);
});

app.get("/api/orders",auth,(req,res)=>{
 const {status,date,waiter,search}=req.query;
 let sql=`SELECT o.*,u.name waiter,a.name accepted_name FROM orders o LEFT JOIN users u ON u.id=o.waiter_id LEFT JOIN users a ON a.id=o.accepted_by WHERE 1=1`;
 const args=[];
 if(status){sql+=" AND o.status=?";args.push(status)}
 if(date){sql+=" AND substr(o.created_at,1,10)=?";args.push(date)}
 if(waiter){sql+=" AND o.waiter_id=?";args.push(Number(waiter))}
 if(search){sql+=" AND (CAST(o.id AS TEXT) LIKE ? OR o.table_number LIKE ? OR u.name LIKE ?)";const q="%"+search+"%";args.push(q,q,q)}
 sql+=" ORDER BY o.id DESC LIMIT 500";
 const rows=db.prepare(sql).all(...args);rows.forEach(o=>o.items=db.prepare("SELECT * FROM order_items WHERE order_id=?").all(o.id));
 res.json(rows);
});

app.patch("/api/orders/:id/accept",auth,requireAdmin,(req,res)=>{
 const o=fullOrder(req.params.id);if(!o)return res.status(404).json({error:"Order not found"});
 if(!["pending","corrected"].includes(o.status))return res.status(400).json({error:"Order is not pending"});
 db.prepare("UPDATE orders SET status='accepted',accepted_at=?,accepted_by=? WHERE id=?").run(now(),req.user.id,o.id);
 const n=fullOrder(o.id);audit(req.user,"Accepted order",o.id,o,n);io.emit("order-updated",n);res.json(n);
});
app.patch("/api/orders/:id/cancel",auth,requireAdmin,(req,res)=>{
 const o=fullOrder(req.params.id);if(!o)return res.status(404).json({error:"Order not found"});
 const reason=(req.body.reason||"No reason provided").trim();
 db.prepare("UPDATE orders SET status='cancelled',cancelled_at=?,cancelled_by=?,cancellation_reason=? WHERE id=?").run(now(),req.user.id,reason,o.id);
 const n=fullOrder(o.id);audit(req.user,"Cancelled order",o.id,o,n,reason);io.emit("order-updated",n);res.json(n);
});
app.patch("/api/orders/:id/complete",auth,requireAdmin,(req,res)=>{
 const o=fullOrder(req.params.id);if(!o)return res.status(404).json({error:"Order not found"});
 db.prepare("UPDATE orders SET status='completed' WHERE id=?").run(o.id);const n=fullOrder(o.id);
 audit(req.user,"Completed order",o.id,o,n);io.emit("order-updated",n);res.json(n);
});
app.put("/api/orders/:id",auth,requireAdmin,(req,res)=>{
 const o=fullOrder(req.params.id);if(!o)return res.status(404).json({error:"Order not found"});
 if(!["pending","accepted","corrected"].includes(o.status))return res.status(400).json({error:"Cannot edit this order"});
 const get=db.prepare("SELECT * FROM products WHERE id=?");let sub=0,norm=[];
 for(const x of req.body.items||[]){const p=get.get(Number(x.product_id)),q=Number(x.quantity);if(!p||q<1)continue;sub+=p.price*q;norm.push({p,q});}
 const rate=Number(db.prepare("SELECT tax_rate FROM settings WHERE id=1").get().tax_rate||0),tax=Math.round(sub*rate)/100;
 const tx=db.transaction(()=>{db.prepare("DELETE FROM order_items WHERE order_id=?").run(o.id);
  const add=db.prepare("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price,total) VALUES(?,?,?,?,?,?)");
  norm.forEach(x=>add.run(o.id,x.p.id,x.p.name,x.q,x.p.price,x.p.price*x.q));
  db.prepare("UPDATE orders SET subtotal=?,tax=?,total=?,status='corrected',notes=? WHERE id=?").run(sub,tax,sub+tax,req.body.notes||o.notes,o.id);
 });tx();const n=fullOrder(o.id);audit(req.user,"Edited order",o.id,o,n,req.body.reason||"Correction");io.emit("order-updated",n);res.json(n);
});

app.get("/api/users",auth,requireAdmin,(req,res)=>res.json(db.prepare("SELECT id,name,username,role,active,created_at FROM users ORDER BY name").all()));
app.post("/api/users",auth,requireAdmin,(req,res)=>{
 const {name,username,password,role="waiter"}=req.body;
 if(!name||!username||!password)return res.status(400).json({error:"Name, username and password required"});
 const r=db.prepare("INSERT INTO users(name,username,password_hash,role,created_at) VALUES(?,?,?,?,?)")
 .run(name,username,bcrypt.hashSync(password,12),role,now());audit(req.user,"Added user",null,null,{id:r.lastInsertRowid,name,username,role});res.json({ok:true});
});
app.patch("/api/users/:id",auth,requireAdmin,(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.params.id);if(!u)return res.status(404).json({error:"Not found"});
 if(req.body.password)db.prepare("UPDATE users SET name=?,active=?,role=?,password_hash=? WHERE id=?").run(req.body.name,u.active,req.body.role,bcrypt.hashSync(req.body.password,12),u.id);
 else db.prepare("UPDATE users SET name=?,active=?,role=? WHERE id=?").run(req.body.name,req.body.active?1:0,req.body.role,u.id);
 audit(req.user,"Updated user",null,u,{id:u.id,name:req.body.name,role:req.body.role,active:req.body.active});res.json({ok:true});
});

app.get("/api/dashboard",auth,requireAdmin,(req,res)=>{
 const date=req.query.date||localDate();
 const totals=db.prepare(`SELECT COUNT(*) orders,
 COALESCE(SUM(CASE WHEN status NOT IN ('cancelled','rejected') THEN total ELSE 0 END),0) income,
 SUM(CASE WHEN status='accepted' THEN 1 ELSE 0 END) accepted,
 SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END) cancelled,
 SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) pending
 FROM orders WHERE substr(created_at,1,10)=?`).get(date);
 const avg=totals.orders?totals.income/totals.orders:0;
 const waiters=db.prepare(`SELECT u.id,u.name,COUNT(o.id) orders,
 COALESCE(SUM(CASE WHEN o.status NOT IN ('cancelled','rejected') THEN o.total ELSE 0 END),0) total,
 SUM(CASE WHEN o.status='cancelled' THEN 1 ELSE 0 END) cancelled
 FROM users u LEFT JOIN orders o ON o.waiter_id=u.id AND substr(o.created_at,1,10)=?
 WHERE u.role IN ('waiter','admin_waiter') GROUP BY u.id ORDER BY total DESC`).all(date);
 res.json({...totals,average:avg,waiters,date});
});

app.post("/api/payments",auth,requireAdmin,(req,res)=>{
 const o=fullOrder(req.body.order_id);if(!o)return res.status(404).json({error:"Order not found"});
 const amount=Number(req.body.amount);if(amount<=0)return res.status(400).json({error:"Invalid amount"});
 const r=db.prepare("INSERT INTO payments(order_id,amount,method,recorded_by,created_at) VALUES(?,?,?,?,?)")
 .run(o.id,amount,req.body.method||"cash",req.user.id,now());
 audit(req.user,"Recorded payment",o.id,null,{amount,method:req.body.method||"cash"});res.json({id:r.lastInsertRowid});
});

app.get("/api/calls",auth,(req,res)=>res.json(db.prepare(`SELECT c.*,u.name waiter,cu.name caller FROM calls c
 LEFT JOIN users u ON u.id=c.waiter_id LEFT JOIN users cu ON cu.id=c.caller_id
 WHERE c.acknowledged_at IS NULL ORDER BY c.id DESC`).all()));
app.post("/api/calls",auth,requireAdmin,(req,res)=>{
 const r=db.prepare("INSERT INTO calls(caller_id,waiter_id,message,created_at) VALUES(?,?,?,?)").run(req.user.id,req.body.waiter_id,req.body.message||"Please come to the main station.",now());
 const call=db.prepare(`SELECT c.*,u.name waiter,cu.name caller FROM calls c LEFT JOIN users u ON u.id=c.waiter_id LEFT JOIN users cu ON cu.id=c.caller_id WHERE c.id=?`).get(r.lastInsertRowid);
 io.to("user:"+req.body.waiter_id).emit("call",call);res.json(call);
});
app.patch("/api/calls/:id/ack",auth,(req,res)=>{
 const c=db.prepare("SELECT * FROM calls WHERE id=?").get(req.params.id);
 if(!c||c.waiter_id!==req.user.id)return res.status(403).json({error:"Not your call"});
 db.prepare("UPDATE calls SET acknowledged_at=? WHERE id=?").run(now(),c.id);
 const n=db.prepare("SELECT * FROM calls WHERE id=?").get(c.id);io.emit("call-ack",n);audit(req.user,"Acknowledged waiter call");res.json(n);
});
app.get("/api/audit",auth,requireAdmin,(req,res)=>res.json(db.prepare(`SELECT a.*,u.name user_name FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 500`).all()));

app.get("/api/print/:id",auth,requireAdmin,(req,res)=>{
 const o=fullOrder(req.params.id),s=db.prepare("SELECT * FROM settings WHERE id=1").get();
 if(!o)return res.status(404).send("Not found");
 res.json({settings:s,order:o});
});
app.get("/print/:id",auth,(req,res)=>{
 const o=fullOrder(req.params.id),s=db.prepare("SELECT * FROM settings WHERE id=1").get();
 if(!o)return res.status(404).send("Not found");
 const esc=x=>String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
 res.send(`<!doctype html><html><head><meta charset="utf-8"><title>4 YJET Check #${o.id}</title>
 <style>body{font-family:Arial,sans-serif;width:72mm;margin:0 auto;padding:5mm;color:#111}
 h2{text-align:center;margin:0 0 4px}.c{text-align:center}.line{display:flex;justify-content:space-between;margin:4px 0}
 hr{border:0;border-top:1px dashed #111}.total{font-size:18px;font-weight:700}@media print{@page{size:80mm auto;margin:0}body{width:72mm}}
 </style></head><body><h2>${esc(s.restaurant_name)}</h2><div class=c>${esc(s.city)}, ${esc(s.region)}, ${esc(s.country)}<br>${esc(s.phone)}</div><hr>
 <b>ORDER #${o.id}</b><br>TABLE: ${esc(o.table_number)}<br>WAITER: ${esc(o.waiter)}<br>TIME: ${new Date(o.created_at).toLocaleString()}<hr>
 ${o.items.map(i=>`<div class=line><span>${i.quantity} × ${esc(i.product_name)}</span><span>${Number(i.total).toFixed(2)}${esc(s.currency)}</span></div>`).join("")}
 <hr><div class=line><span>SUBTOTAL</span><span>${Number(o.subtotal).toFixed(2)}${esc(s.currency)}</span></div>
 <div class=line><span>TAX</span><span>${Number(o.tax).toFixed(2)}${esc(s.currency)}</span></div>
 <div class="line total"><span>TOTAL</span><span>${Number(o.total).toFixed(2)}${esc(s.currency)}</span></div>
 <p class=c>Thank you!</p><script>window.onload=()=>window.print()</script></body></html>`);
});

io.on("connection",socket=>socket.on("identify",id=>{if(id)socket.join("user:"+id)}));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
server.listen(3000,"0.0.0.0",()=>console.log("4 YJET POS: http://localhost:3000"));