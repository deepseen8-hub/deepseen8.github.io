@echo off
setlocal
title 4 YJET POS - MAIN SERVER
cd /d "%~dp0"
echo.
echo ==========================================
echo              4 YJET POS
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found.
  echo.
  echo Install Node.js LTS, then double-click this file again.
  echo.
  pause
  exit /b
)

if not exist node_modules (
  echo First setup: installing POS packages...
  call npm install
  if errorlevel 1 (
    echo.
    echo Package installation failed.
    pause
    exit /b
  )
)

echo.
echo Starting POS server...
echo Main PC: http://localhost:3000
echo.
echo Keep this window OPEN while the POS is being used.
echo.
start "" http://localhost:3000
node server.js
pause
